"""
GenAI Demo App – Assignment 39
A simple conversational assistant ready for deployment on
Streamlit Cloud and Hugging Face Spaces.

Features:
  • Chat interface with session history
  • Optional OpenAI backend (set OPENAI_API_KEY in secrets)
  • Fallback local responses when no key is present
"""

import os
import streamlit as st

st.set_page_config(
    page_title="GenAI Assistant",
    page_icon="🤖",
    layout="centered",
)

st.title("🤖 GenAI Assistant")
st.caption("Assignment 39 – Deployable Streamlit app (Streamlit Cloud & Hugging Face Spaces)")

# ------------------------------------------------------------------
# Optional OpenAI backend
# ------------------------------------------------------------------
def get_openai_reply(prompt: str, history: list) -> str:
    try:
        from langchain_openai import ChatOpenAI
        from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
        from langchain_core.messages import HumanMessage, AIMessage
        from langchain_core.output_parsers import StrOutputParser

        api_key = os.getenv("OPENAI_API_KEY") or st.secrets.get("OPENAI_API_KEY", "")
        if not api_key:
            return None

        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.4, api_key=api_key)
        prompt_tmpl = ChatPromptTemplate.from_messages(
            [
                ("system", "You are a helpful, concise assistant."),
                MessagesPlaceholder("history", optional=True),
                ("human", "{question}"),
            ]
        )
        chain = prompt_tmpl | llm | StrOutputParser()

        lc_history = []
        for m in history:
            if m["role"] == "user":
                lc_history.append(HumanMessage(content=m["content"]))
            else:
                lc_history.append(AIMessage(content=m["content"]))

        return chain.invoke({"question": prompt, "history": lc_history})
    except Exception as e:
        return f"(OpenAI error: {e})"


def fallback_reply(prompt: str) -> str:
    """Simple offline responses so the app always works after deployment."""
    p = prompt.lower()
    if any(w in p for w in ["hello", "hi", "hey"]):
        return "Hello! I'm a GenAI demo assistant. Ask me anything."
    if "deploy" in p:
        return (
            "This app is designed to be deployed on **Streamlit Cloud** and "
            "**Hugging Face Spaces**. Check the README for step-by-step guides."
        )
    if "streamlit" in p:
        return (
            "Streamlit Cloud is free for public apps. Connect your GitHub repo, "
            "set the main file to `app.py`, and click Deploy."
        )
    if "hugging" in p or "space" in p:
        return (
            "Hugging Face Spaces supports Streamlit apps. Create a Space, "
            "choose the Streamlit SDK, and push `app.py` + `requirements.txt`."
        )
    if "who are you" in p or "what are you" in p:
        return "I'm a lightweight GenAI assistant built for Assignment 39 (deployment demo)."
    return (
        f"You said: “{prompt}”\n\n"
        "I'm running in offline/demo mode. "
        "Add an `OPENAI_API_KEY` in Streamlit secrets (or HF Space secrets) "
        "to enable full LLM replies."
    )


# ------------------------------------------------------------------
# Session state
# ------------------------------------------------------------------
if "messages" not in st.session_state:
    st.session_state.messages = []

with st.sidebar:
    st.header("About")
    st.markdown(
        "Deployable GenAI app for **Assignment 39**.\n\n"
        "Works out-of-the-box. Optional: add `OPENAI_API_KEY` "
        "in platform secrets for live LLM answers."
    )
    st.markdown("---")
    if st.button("Clear chat"):
        st.session_state.messages = []
        st.rerun()
    st.markdown(
        "**Platforms**\n"
        "- [Streamlit Cloud](https://streamlit.io/cloud)\n"
        "- [Hugging Face Spaces](https://huggingface.co/spaces)"
    )

# Display history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input
if user_input := st.chat_input("Ask something…"):
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    with st.chat_message("assistant"):
        with st.spinner("Thinking…"):
            reply = get_openai_reply(user_input, st.session_state.messages[:-1])
            if reply is None:
                reply = fallback_reply(user_input)
            st.markdown(reply)

    st.session_state.messages.append({"role": "assistant", "content": reply})
