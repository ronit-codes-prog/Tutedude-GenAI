# Assignment 39: GenAI App Deployment

**Deploy a GenAI Streamlit application on Streamlit Cloud and Hugging Face Spaces.**

This repository contains a ready-to-deploy conversational assistant.  
It works offline with built-in fallback replies and can use OpenAI when an API key is provided in platform secrets.

---

## Project Structure

```
GenAI-Task39-AppDeployment/
├── app.py               # Main Streamlit application
├── requirements.txt     # Dependencies
└── README.md            # This file (deployment guides + comparison)
```

---

## Local Run (optional)

```bash
pip install -r requirements.txt
streamlit run app.py
```

---

## Task 1 – Deployment on Streamlit Cloud

### Steps

1. **Push the project to GitHub**
   ```bash
   git init
   git add app.py requirements.txt README.md
   git commit -m "GenAI app for Streamlit Cloud"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```

2. **Required files** (already present)
   - `app.py`
   - `requirements.txt`

3. **Deploy on Streamlit Cloud**
   - Go to [https://share.streamlit.io](https://share.streamlit.io) (or streamlit.io/cloud)
   - Sign in with GitHub
   - Click **New app**
   - Select the repository, branch (`main`), and main file path: `app.py`
   - Click **Deploy**

4. **Optional – OpenAI key**
   - In the app settings → **Secrets**
   - Add:
     ```toml
     OPENAI_API_KEY = "sk-..."
     ```

5. **Test the live URL**
   - Streamlit provides a public URL like  
     `https://<app-name>.streamlit.app`
   - Open it and send a few chat messages to verify.

---

## Task 2 – Deployment on Hugging Face Spaces

### Steps

1. **Create a new Space**
   - Go to [https://huggingface.co/spaces](https://huggingface.co/spaces)
   - Click **Create new Space**
   - Choose **SDK → Streamlit**
   - Set visibility (Public is free)
   - Create the Space

2. **Connect GitHub or upload files**
   - **Option A – GitHub**  
     Link the same repository used for Streamlit Cloud.
   - **Option B – Manual upload**  
     Upload `app.py`, `requirements.txt`, and this `README.md` via the web UI or:
     ```bash
     git clone https://huggingface.co/spaces/<your-username>/<space-name>
     cp app.py requirements.txt README.md <space-name>/
     cd <space-name>
     git add .
     git commit -m "Deploy GenAI Streamlit app"
     git push
     ```

3. **Configure secrets (optional)**
   - Space → Settings → Repository secrets  
   - Add `OPENAI_API_KEY`

4. **Deploy and test**
   - Hugging Face builds the Space automatically.
   - Open the Space URL and chat with the assistant.

---

## Task 3 – Compare Deployment Platforms

### 1. Streamlit Cloud vs Hugging Face Spaces

| Aspect | Streamlit Cloud | Hugging Face Spaces |
|--------|-----------------|---------------------|
| Primary focus | Streamlit apps | Any demo (Streamlit, Gradio, Docker, static) |
| Auth | GitHub account | Hugging Face account |
| Free tier | Public apps free; private apps limited | Public Spaces free; private limited |
| Secrets | App → Settings → Secrets (TOML) | Space → Settings → Secrets |
| Custom domains | Paid plans | Limited |
| GPU | Not on free tier | Available on paid / ZeroGPU |

### 2. Pros & Cons

**Streamlit Cloud**
- Pros: One-click from GitHub, excellent Streamlit integration, simple secrets, automatic rebuilds on push.
- Cons: Only Streamlit; free tier sleeps after inactivity; limited hardware.

**Hugging Face Spaces**
- Pros: Supports Streamlit *and* Gradio/Docker; large ML community; easy model hosting; optional GPU.
- Cons: Slightly more setup; build times can be longer; free CPU Spaces also sleep.

### 3. When to use which

- **Streamlit Cloud** – pure Streamlit apps, fastest path from GitHub repo to public URL, internal/team demos.
- **Hugging Face Spaces** – when you also need model hosting, Gradio UIs, Docker, or want the app discoverable in the HF ecosystem.

Many teams deploy the same repo to **both** platforms for redundancy and different audiences.

---

## Validation Checklist

- [ ] App runs locally (`streamlit run app.py`)
- [ ] Pushed to GitHub with `app.py` + `requirements.txt`
- [ ] Deployed on Streamlit Cloud → live URL works
- [ ] Deployed on Hugging Face Spaces → live URL works
- [ ] (Optional) `OPENAI_API_KEY` set in secrets on both platforms

---

## Submission

- Rename the outer folder to `GenAI-Task39-YourName` if required.
- Include all code files and this `README.md`.
- Zip the folder and upload to the submission portal.
- (Recommended) Also include the two live URLs in your submission notes.
